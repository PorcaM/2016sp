#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>

#include "smalloc1.h"

#define MAX_ITEMS 20


typedef struct {
	int sz;
	int line;
	char file[256];
	void* addr;
} mem_usage;

static int _idx = 0;
static mem_usage _trmem[MAX_ITEMS];


void *smart_malloc_int (size_t size, char *file, int line)
{
	/* TODO: Add your code here */
	return NULL;
}

void smart_free_int (void* p, char *file, int line)
{
	/* TODO: Add your code here */
}

int smart_leakcheck ()
{
	/* TODO: Add your code here */
	return -1;
}

int smart_set_int (void *ptr, int offset, int value, char *file, int line)
{
	/* TODO: Add your code here */
	return -1;
}

int smart_get_int (void *ptr, int offset, char *file, int line)
{
	/* TODO: Add your code here */
	return -1;
}

