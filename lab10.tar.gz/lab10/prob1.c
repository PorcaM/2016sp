#include <stdio.h>
#include <stdlib.h>

int main (int argc, char** argv)
{
	/* TODO: Impelement your code here */

	return 0;
}

