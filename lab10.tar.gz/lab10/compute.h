int compute1 ();
int compute2 ();
int compute3 ();
int compute4 ();
int compute5 ();

