#include <stdio.h>


#define A(i,j) a[ (i)*n + (j) ]
#define B(i,j) b[ (i)*n + (j) ]
#define C(i,j) c[ (i)*n + (j) ]

/* Routine for computing C = A * B + C */

void MY_MMult( int n, double *a, double *b, double *c)
{
	int i, j, k;

	for ( i=0; i<n; i++ ){
		for ( j=0; j<n; j++ ){
			for ( k=0; k<n; k++ ){
				C( i,j ) = C( i,j ) +  A( i,k ) * B( k,j );
			}
		}
	}
}

