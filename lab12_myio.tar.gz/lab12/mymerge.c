#include <stdio.h>
#include <stdlib.h>


int main (int argc, char** argv)
{
	unsigned char** buf = NULL;
	int* fsize;
	int ret, nr_srcfiles, i;
	char key;

	/* check arguments */
	if (argc < 4) {
		printf ("usage: mymerge mergedfile key srcfile1 srcfile2 ...\n");
		exit (-1);
	}

	/* TODO: Add your code here */

	return 0;
}

