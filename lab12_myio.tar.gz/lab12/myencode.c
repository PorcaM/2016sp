#include <stdio.h>
#include <stdlib.h>


int main (int argc, char** argv)
{
	char* buf = NULL;
	int fsize, ret;
	char key;

	/* check arguments */
	if (argc != 4) {
		printf ("usage: myencode src dst key\n");
		exit (-1);
	}

	/* TODO: Add your code here */

	return 0;
}

