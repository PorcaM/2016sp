#include <stdio.h>
#include <stdlib.h>


int main (int argc, char** argv)
{
	char* buf = NULL;
	int fsize, ret;

	/* check arguments */
	if (argc != 3) {
		printf ("usage: mycp src dst\n");
		exit (-1);
	}

	/* TODO: Add your code here */

	return 0;
}

